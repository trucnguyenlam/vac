* Use Allman style
* Don't use any non-standard-library libraries
* Keep everything in the args namespace
* Keep it simple and fast
