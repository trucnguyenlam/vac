#pragma once

namespace VAC {

} // VAC
